
class NailService:
    def __init__(self):
        # Initialize the available nail services and their prices
        self.services = {
            'Manicure': 25.00,
            'Pedicure': 35.00,
            'Acrylic Nails': 40.00,
            'Gel Nails': 45.00,
            'Nail Art': 10.00,
        }

    def display_services(self):
        # Display the available nail services with their prices
        print("Services Menu:")
        for service, price in self.services.items():
            print(f"{service}: ${price:.2f}")


class Appointment:
    def __init__(self):
        # Initialize the appointment details
        self.selected_services = {}
        self.appointment_date = None
        self.appointment_time = None

    def add_to_appointment(self, service, quantity):
        # Add selected services and their quantities to the appointment
        if service not in NailService().services:
            raise InvalidInputError("Invalid service selected.")
        if quantity <= 0:
            raise InvalidInputError("Quantity should be greater than zero.")
        self.selected_services[service] = quantity

    def set_appointment_date_time(self, appointment_date, appointment_time):
        # Set the appointment date and time
        self.appointment_date = appointment_date
        self.appointment_time = appointment_time

    def get_total_cost(self):
        # Calculate and return the total cost of selected services
        total = 0
        for service, quantity in self.selected_services.items():
            total += NailService().services[service] * quantity
        return total


def save_appointment_summary(appointment_details):
    # Save the appointment details to a text file
    with open('appointment_summary.txt', 'w') as file:
        file.write(appointment_details)


def schedule_nail_service():
    try:
        nail_service = NailService()
        appointment = Appointment()

        # Display available nail services to the user
        nail_service.display_services()

        for service, price in nail_service.services.items():
            # Ask the user for the quantity of each service they want to schedule
            quantity = int(input(f"How many {service}s do you want to schedule? "))
            if quantity > 0:
                appointment.add_to_appointment(service, quantity)

        # Ask the user to enter the appointment date and time
        appointment_date = input("Please enter the appointment date (YYYY-MM-DD): ")
        appointment_time = input("Please enter the appointment time (HH:MM): ")
        appointment.set_appointment_date_time(appointment_date, appointment_time)

        # Generate the appointment details for the user
        appointment_details = f"Appointment Details:\n"
        for service, quantity in appointment.selected_services.items():
            appointment_details += f"{service} x{quantity}: ${nail_service.services[service] * quantity:.2f}\n"
        appointment_details += f"Total: ${appointment.get_total_cost():.2f}\n"
        appointment_details += f"Appointment Date and Time: {appointment_date} {appointment_time}\n"

        # Save the appointment summary to a text file
        save_appointment_summary(appointment_details)

        # Display the appointment summary to the user
        print("\nAppointment Summary:")
        print(appointment_details)

    except InvalidInputError as e:
        # Handle invalid input errors
        print(f"Error: {e}")
    except Exception as e:
        # Handle unexpected errors
        print(f"An unexpected error occurred: {e}")


if __name__ == "__main__":
    schedule_nail_service()
